# AppDirect Skills

Claude Code / Cowork skills for AppDirect marketplace work, by Jason Brashear (Titanium Computing).

- `.claude/skills/appdirect-submission` — app submission runbook: 100% profile-completion checklist, publication flow, rejection recovery
- `.claude/skills/appdirect-api-integration` — API integration: OAuth/scopes, GraphQL product mutations, integration configs, TS scaffolds

Install: copy the folders into your project's `.claude/skills/` (or `~/.claude/skills/` for global use). Verified against developer.appdirect.com, 2026-07-08.
